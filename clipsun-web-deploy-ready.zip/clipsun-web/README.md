# ClipStudio Web — browser video editor MVP

ClipStudio Web is a responsive website built with React, TypeScript, Vite, and FFmpeg.wasm. It is a browser website, not an APK or desktop app. The same source code targets mobile and desktop browsers.

## Current scope

- Thai and English interface switching.
- Local video and audio file import.
- Browser video preview and playhead navigation.
- Clip trim start/end, split, duplicate, delete, and reorder controls.
- Vertical 9:16, landscape 16:9, and square 1:1 project ratios.
- Thai/English subtitle rows, manual timestamp editing, SRT import/export.
- Text/title overlay controls and music volume controls.
- JSON project settings export/import. Original media is not embedded.
- FFmpeg.wasm WebM export path with progress reporting and a generated-file download.
- GitHub Actions workflow to build and deploy the static website to GitHub Pages after the owner configures Pages.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

Vite's deployable output is in `dist/`.

## Publish a public HTTPS URL with GitHub Pages

A public URL cannot be created from this project bundle alone: it must be pushed to a repository under an account you control and the host must be authorized. This repository includes `.github/workflows/deploy-pages.yml` to automate build and deployment.

1. Create a new GitHub repository and upload/push the contents of this project to the `main` branch. Ensure `package.json`, `src/`, `index.html`, and `.github/` are at the repository root.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **GitHub Actions** as the source.
4. Open **Actions**, run **Build and deploy ClipStudio Web** if it did not start automatically, and wait for both jobs to pass.
5. Open **Settings → Pages** or the completed deployment job to find the actual public URL. GitHub Pages URLs commonly follow `https://<account>.github.io/<repository>/`; use the exact URL shown by GitHub rather than guessing.

The workflow uses `npm ci`, so commit a generated `package-lock.json` before first deployment. Generate it locally with `npm install`, then commit both `package.json` and `package-lock.json`. This environment could not complete `npm install`, so a lockfile and verified CI build are not included yet. GitHub Actions will not deploy until the lockfile is committed and the workflow succeeds.

Other compatible static hosts include Cloudflare Pages, Netlify, and Vercel. Use build command `npm run build` and output directory `dist`.

## Privacy and external assets

Media files are selected and processed in the browser; this app does not upload the video to a project backend. On first export, FFmpeg WebAssembly assets are downloaded from unpkg. For production reliability, self-host matching FFmpeg core assets and adjust `loadEngine()` URLs. Do not put private API keys in frontend code.

## Known limitations — not verified as complete

- Multi-clip export is not fully implemented: the current FFmpeg export renders the selected clip, not the entire timeline as one continuous sequence.
- MP4 export is not enabled; WebM is the available output path.
- Thai glyph rendering when subtitles are burned into the video depends on FFmpeg core/font availability. Verify with actual Thai sample files on the deployed host. UTF-8 SRT export is available as a separate file.
- Automatic speech recognition, transcript-based AI highlight detection, and AI translation are not configured. The clip suggestion panel makes a manual duration-based highlight, not an AI-generated transcript analysis.
- Audio trimming and positioning are not fully implemented. Background audio mixing is limited to the selected clip export path.
- Project JSON preserves settings and clip metadata, not the source video/audio bytes. Re-import media files on another device.
- Large videos may exhaust browser memory. Use a shorter clip, lower resolution, or a desktop browser if export fails.
- MP4/WebM decoding and encoding depend on browser and FFmpeg build support.
- This environment could not finish `npm install`; therefore a production build, actual browser rendering, and end-to-end export tests have not been verified here.

Do not advertise the app as production-tested until the dependency install, CI build, mobile/desktop browser tests, and actual exported-file playback have passed.
